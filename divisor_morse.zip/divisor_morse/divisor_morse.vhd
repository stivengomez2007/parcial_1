library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity divisor_morse is
    port (
        clk  : in  std_logic; 
        reset: in  std_logic; 
        pulso : out std_logic  
    );
end entity divisor_morse;

architecture contador of divisor_morse is
    signal count : integer range 0 to 25000000 := 0;
begin
    process(clk, reset)
    begin
        if reset = '0' then
            count <= 0;
            pulso <= '0';
        elsif rising_edge(clk) then
            if count = 24999999 then
                count <= 0;
                pulso <= '1';
            else
                count <= count + 1;
                pulso <= '0';
            end if;
        end if;
    end process;
end architecture contador;