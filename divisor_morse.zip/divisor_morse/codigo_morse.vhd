library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity codigo_morse is
    port (
        CLOCK_50 : in  std_logic;                    
        KEY      : in  std_logic_vector(1 downto 0); 
        SW       : in  std_logic_vector(2 downto 0); 
        LEDR     : out std_logic_vector(0 downto 0)  
    );
end entity codigo_morse;

architecture codigo of codigo_morse is

    
    component divisor_morse is
        port (
            clk   : in  std_logic;
            reset : in  std_logic;
            pulso: out std_logic
        );
    end component;

    
    signal pulse_tick : std_logic; 
    
    
    type state_type is (IDLE, LOAD, PULSE, SPACE);
    signal state : state_type := IDLE;

    signal shift_reg   : std_logic_vector(3 downto 0) := "0000";
    signal length_cnt  : integer range 0 to 4 := 0;
    signal pulse_ticks : integer range 0 to 3 := 0;
    signal target_ticks: integer range 0 to 3 := 0;

begin

    
    RELOJ: divisor_morse
        port map (
            clk  => CLOCK_50,   
            reset  => KEY(0),     
            pulso => pulse_tick  
        );

    
    process(CLOCK_50, KEY(0))
    begin
        if KEY(0) = '0' then 
            state        <= IDLE;
            shift_reg    <= "0000";
            length_cnt   <= 0;
            pulse_ticks  <= 0;
            target_ticks <= 0;
            LEDR(0)      <= '0';

        elsif rising_edge(CLOCK_50) then
            case state is

                when IDLE =>
                    LEDR(0) <= '0';
                    
                    if KEY(1) = '0' then
                        case SW is
                            when "000" => shift_reg <= "0100"; length_cnt <= 2; 
                            when "001" => shift_reg <= "1000"; length_cnt <= 4; 
                            when "010" => shift_reg <= "1010"; length_cnt <= 4; 
                            when "011" => shift_reg <= "1000"; length_cnt <= 3; 
                            when "100" => shift_reg <= "0000"; length_cnt <= 1; 
                            when "101" => shift_reg <= "0010"; length_cnt <= 4; 
                            when "110" => shift_reg <= "1100"; length_cnt <= 3; 
                            when "111" => shift_reg <= "0000"; length_cnt <= 4; 
                            when others => length_cnt <= 0;
                        end case;
                        state <= LOAD;
                    end if;

                when LOAD=>
                    if length_cnt > 0 then
                        if shift_reg(3) = '0' then
                            target_ticks <= 1; 
                        else
                            target_ticks <= 3; 
                        end if;

                        shift_reg   <= shift_reg(2 downto 0) & '0';
                        length_cnt  <= length_cnt - 1;
                        pulse_ticks <= 0;
                        state       <= PULSE;
                    else
                        state <= IDLE;
                    end if;

                when PULSE =>
                    LEDR(0) <= '1';
                   
                    if pulse_tick = '1' then
                        if pulse_ticks + 1 = target_ticks then
                            pulse_ticks <= 0;
                            state       <= SPACE;
                        else
                            pulse_ticks <= pulse_ticks + 1;
                        end if;
                    end if;

                when SPACE =>
                    LEDR(0) <= '0';
                    if pulse_tick = '1' then
                        if length_cnt > 0 then
                            state <= LOAD;
                        else
                            state <= IDLE;
                        end if;
                    end if;

                when others =>
                    state <= IDLE;

            end case;
        end if;
    end process;

end architecture codigo;