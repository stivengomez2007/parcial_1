library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity testbech_morse is
end entity testbech_morse;

architecture sim of testbech_morse is

    component codigo_morse is
        port (
            CLOCK_50 : in  std_logic;
            KEY      : in  std_logic_vector(1 downto 0);
            SW       : in  std_logic_vector(2 downto 0);
            LEDR     : out std_logic_vector(0 downto 0)
        );
    end component;

    signal clk  : std_logic := '0';
    signal key  : std_logic_vector(1 downto 0) := "11";
    signal sw   : std_logic_vector(2 downto 0) := "000";
    signal ledr : std_logic_vector(0 downto 0);

    constant period : time := 20 ns;

begin

    UUT: codigo_morse
        port map (
            CLOCK_50 => clk,
            KEY      => key,
            SW       => sw,
            LEDR     => ledr
        );

    process
    begin
        clk <= '0';
        wait for period / 2;
        clk <= '1';
        wait for period / 2;
    end process;

    process
    begin
        key(0) <= '0';
        wait for 40 ns;
        key(0) <= '1';
        wait for 40 ns;

        sw <= "000";
        wait for 20 ns;
        
        key(1) <= '0';
        wait for 40 ns;
        key(1) <= '1';

        wait for 5 sec;

        sw <= "100";
        wait for 20 ns;

        key(1) <= '0';
        wait for 40 ns;
        key(1) <= '1';

        wait;
    end process;

end architecture;