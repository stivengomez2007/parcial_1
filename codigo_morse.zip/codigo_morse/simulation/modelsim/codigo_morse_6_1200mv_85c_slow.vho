-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 14:25:11"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	codigo_morse IS
    PORT (
	CLOCK_50 : IN std_logic;
	KEY : IN std_logic_vector(1 DOWNTO 0);
	SW : IN std_logic_vector(2 DOWNTO 0);
	LEDR : OUT std_logic_vector(0 DOWNTO 0)
	);
END codigo_morse;

-- Design Ports Information
-- LEDR[0]	=>  Location: PIN_N2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLOCK_50	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[0]	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[1]	=>  Location: PIN_M6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[0]	=>  Location: PIN_M1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[2]	=>  Location: PIN_M2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[1]	=>  Location: PIN_L6,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF codigo_morse IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLOCK_50 : std_logic;
SIGNAL ww_KEY : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_SW : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_LEDR : std_logic_vector(0 DOWNTO 0);
SIGNAL \CLOCK_50~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \KEY[0]~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \LEDR[0]~output_o\ : std_logic;
SIGNAL \CLOCK_50~input_o\ : std_logic;
SIGNAL \CLOCK_50~inputclkctrl_outclk\ : std_logic;
SIGNAL \KEY[1]~input_o\ : std_logic;
SIGNAL \SW[1]~input_o\ : std_logic;
SIGNAL \SW[2]~input_o\ : std_logic;
SIGNAL \SW[0]~input_o\ : std_logic;
SIGNAL \length_cnt[0]~6_combout\ : std_logic;
SIGNAL \length_cnt[0]~7_combout\ : std_logic;
SIGNAL \KEY[0]~input_o\ : std_logic;
SIGNAL \KEY[0]~inputclkctrl_outclk\ : std_logic;
SIGNAL \length_cnt[2]~0_combout\ : std_logic;
SIGNAL \length_cnt[2]~1_combout\ : std_logic;
SIGNAL \length_cnt[2]~2_combout\ : std_logic;
SIGNAL \Selector10~0_combout\ : std_logic;
SIGNAL \target_ticks[0]~feeder_combout\ : std_logic;
SIGNAL \RELOJ|Add0~0_combout\ : std_logic;
SIGNAL \RELOJ|Add0~1\ : std_logic;
SIGNAL \RELOJ|Add0~2_combout\ : std_logic;
SIGNAL \RELOJ|Add0~3\ : std_logic;
SIGNAL \RELOJ|Add0~4_combout\ : std_logic;
SIGNAL \RELOJ|Add0~5\ : std_logic;
SIGNAL \RELOJ|Add0~6_combout\ : std_logic;
SIGNAL \RELOJ|Add0~7\ : std_logic;
SIGNAL \RELOJ|Add0~8_combout\ : std_logic;
SIGNAL \RELOJ|Add0~9\ : std_logic;
SIGNAL \RELOJ|Add0~10_combout\ : std_logic;
SIGNAL \RELOJ|Add0~11\ : std_logic;
SIGNAL \RELOJ|Add0~12_combout\ : std_logic;
SIGNAL \RELOJ|count~11_combout\ : std_logic;
SIGNAL \RELOJ|Add0~13\ : std_logic;
SIGNAL \RELOJ|Add0~14_combout\ : std_logic;
SIGNAL \RELOJ|Add0~15\ : std_logic;
SIGNAL \RELOJ|Add0~16_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~5_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~6_combout\ : std_logic;
SIGNAL \RELOJ|Add0~17\ : std_logic;
SIGNAL \RELOJ|Add0~18_combout\ : std_logic;
SIGNAL \RELOJ|Add0~19\ : std_logic;
SIGNAL \RELOJ|Add0~20_combout\ : std_logic;
SIGNAL \RELOJ|Add0~21\ : std_logic;
SIGNAL \RELOJ|Add0~22_combout\ : std_logic;
SIGNAL \RELOJ|count~10_combout\ : std_logic;
SIGNAL \RELOJ|Add0~23\ : std_logic;
SIGNAL \RELOJ|Add0~24_combout\ : std_logic;
SIGNAL \RELOJ|count~9_combout\ : std_logic;
SIGNAL \RELOJ|Add0~25\ : std_logic;
SIGNAL \RELOJ|Add0~26_combout\ : std_logic;
SIGNAL \RELOJ|count~8_combout\ : std_logic;
SIGNAL \RELOJ|Add0~27\ : std_logic;
SIGNAL \RELOJ|Add0~28_combout\ : std_logic;
SIGNAL \RELOJ|count~7_combout\ : std_logic;
SIGNAL \RELOJ|Add0~29\ : std_logic;
SIGNAL \RELOJ|Add0~30_combout\ : std_logic;
SIGNAL \RELOJ|Add0~31\ : std_logic;
SIGNAL \RELOJ|Add0~32_combout\ : std_logic;
SIGNAL \RELOJ|count~6_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~2_combout\ : std_logic;
SIGNAL \RELOJ|Add0~33\ : std_logic;
SIGNAL \RELOJ|Add0~34_combout\ : std_logic;
SIGNAL \RELOJ|Add0~35\ : std_logic;
SIGNAL \RELOJ|Add0~36_combout\ : std_logic;
SIGNAL \RELOJ|count~5_combout\ : std_logic;
SIGNAL \RELOJ|Add0~37\ : std_logic;
SIGNAL \RELOJ|Add0~38_combout\ : std_logic;
SIGNAL \RELOJ|count~4_combout\ : std_logic;
SIGNAL \RELOJ|Add0~39\ : std_logic;
SIGNAL \RELOJ|Add0~40_combout\ : std_logic;
SIGNAL \RELOJ|count~3_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~1_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~3_combout\ : std_logic;
SIGNAL \RELOJ|Add0~41\ : std_logic;
SIGNAL \RELOJ|Add0~42_combout\ : std_logic;
SIGNAL \RELOJ|count~2_combout\ : std_logic;
SIGNAL \RELOJ|Add0~43\ : std_logic;
SIGNAL \RELOJ|Add0~44_combout\ : std_logic;
SIGNAL \RELOJ|count~1_combout\ : std_logic;
SIGNAL \RELOJ|Add0~45\ : std_logic;
SIGNAL \RELOJ|Add0~46_combout\ : std_logic;
SIGNAL \RELOJ|Add0~47\ : std_logic;
SIGNAL \RELOJ|Add0~48_combout\ : std_logic;
SIGNAL \RELOJ|count~0_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~0_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~4_combout\ : std_logic;
SIGNAL \RELOJ|Equal0~7_combout\ : std_logic;
SIGNAL \RELOJ|pulso~q\ : std_logic;
SIGNAL \Selector10~1_combout\ : std_logic;
SIGNAL \state.PULSE~q\ : std_logic;
SIGNAL \Selector13~0_combout\ : std_logic;
SIGNAL \pulse_ticks[0]~0_combout\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \Selector3~0_combout\ : std_logic;
SIGNAL \Selector12~0_combout\ : std_logic;
SIGNAL \state~12_combout\ : std_logic;
SIGNAL \Selector11~0_combout\ : std_logic;
SIGNAL \state.SPACE~q\ : std_logic;
SIGNAL \Selector8~1_combout\ : std_logic;
SIGNAL \Selector8~2_combout\ : std_logic;
SIGNAL \state.IDLE~q\ : std_logic;
SIGNAL \shift_reg[3]~0_combout\ : std_logic;
SIGNAL \length_cnt[1]~4_combout\ : std_logic;
SIGNAL \length_cnt[1]~3_combout\ : std_logic;
SIGNAL \length_cnt[1]~5_combout\ : std_logic;
SIGNAL \Selector8~0_combout\ : std_logic;
SIGNAL \Selector9~0_combout\ : std_logic;
SIGNAL \Selector9~1_combout\ : std_logic;
SIGNAL \state.LOAD~q\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \LEDR[0]~reg0_q\ : std_logic;
SIGNAL target_ticks : std_logic_vector(1 DOWNTO 0);
SIGNAL shift_reg : std_logic_vector(3 DOWNTO 0);
SIGNAL pulse_ticks : std_logic_vector(1 DOWNTO 0);
SIGNAL length_cnt : std_logic_vector(2 DOWNTO 0);
SIGNAL \RELOJ|count\ : std_logic_vector(24 DOWNTO 0);
SIGNAL \ALT_INV_shift_reg[3]~0_combout\ : std_logic;

BEGIN

ww_CLOCK_50 <= CLOCK_50;
ww_KEY <= KEY;
ww_SW <= SW;
LEDR <= ww_LEDR;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLOCK_50~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLOCK_50~input_o\);

\KEY[0]~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \KEY[0]~input_o\);
\ALT_INV_shift_reg[3]~0_combout\ <= NOT \shift_reg[3]~0_combout\;

-- Location: IOOBUF_X0_Y12_N16
\LEDR[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \LEDR[0]~reg0_q\,
	devoe => ww_devoe,
	o => \LEDR[0]~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\CLOCK_50~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK_50,
	o => \CLOCK_50~input_o\);

-- Location: CLKCTRL_G4
\CLOCK_50~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK_50~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLOCK_50~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y13_N8
\KEY[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(1),
	o => \KEY[1]~input_o\);

-- Location: IOIBUF_X0_Y13_N1
\SW[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(1),
	o => \SW[1]~input_o\);

-- Location: IOIBUF_X0_Y13_N15
\SW[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(2),
	o => \SW[2]~input_o\);

-- Location: IOIBUF_X0_Y13_N22
\SW[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(0),
	o => \SW[0]~input_o\);

-- Location: LCCOMB_X1_Y13_N12
\length_cnt[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[0]~6_combout\ = (!\state.LOAD~q\ & ((\SW[2]~input_o\ & ((!\SW[0]~input_o\))) # (!\SW[2]~input_o\ & (\SW[1]~input_o\ & \SW[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[2]~input_o\,
	datac => \SW[0]~input_o\,
	datad => \state.LOAD~q\,
	combout => \length_cnt[0]~6_combout\);

-- Location: LCCOMB_X1_Y13_N4
\length_cnt[0]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[0]~7_combout\ = (\shift_reg[3]~0_combout\ & (((length_cnt(0))))) # (!\shift_reg[3]~0_combout\ & ((\length_cnt[0]~6_combout\) # ((\state.LOAD~q\ & !length_cnt(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \length_cnt[0]~6_combout\,
	datab => \state.LOAD~q\,
	datac => length_cnt(0),
	datad => \shift_reg[3]~0_combout\,
	combout => \length_cnt[0]~7_combout\);

-- Location: IOIBUF_X0_Y14_N8
\KEY[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(0),
	o => \KEY[0]~input_o\);

-- Location: CLKCTRL_G2
\KEY[0]~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \KEY[0]~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \KEY[0]~inputclkctrl_outclk\);

-- Location: FF_X1_Y13_N5
\length_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \length_cnt[0]~7_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => length_cnt(0));

-- Location: LCCOMB_X1_Y13_N22
\length_cnt[2]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[2]~0_combout\ = (\state.LOAD~q\ & (length_cnt(2) $ (((!length_cnt(1) & !length_cnt(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => length_cnt(1),
	datab => length_cnt(0),
	datac => length_cnt(2),
	datad => \state.LOAD~q\,
	combout => \length_cnt[2]~0_combout\);

-- Location: LCCOMB_X1_Y13_N20
\length_cnt[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[2]~1_combout\ = (!\state.LOAD~q\ & (\SW[0]~input_o\ $ (((\SW[1]~input_o\ & !\SW[2]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[2]~input_o\,
	datac => \SW[0]~input_o\,
	datad => \state.LOAD~q\,
	combout => \length_cnt[2]~1_combout\);

-- Location: LCCOMB_X1_Y13_N8
\length_cnt[2]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[2]~2_combout\ = (\shift_reg[3]~0_combout\ & (((length_cnt(2))))) # (!\shift_reg[3]~0_combout\ & ((\length_cnt[2]~0_combout\) # ((\length_cnt[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \length_cnt[2]~0_combout\,
	datab => \length_cnt[2]~1_combout\,
	datac => length_cnt(2),
	datad => \shift_reg[3]~0_combout\,
	combout => \length_cnt[2]~2_combout\);

-- Location: FF_X1_Y13_N9
\length_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \length_cnt[2]~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => length_cnt(2));

-- Location: LCCOMB_X1_Y13_N14
\Selector10~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector10~0_combout\ = (\state.LOAD~q\ & ((length_cnt(1)) # ((length_cnt(2)) # (length_cnt(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => length_cnt(1),
	datab => length_cnt(2),
	datac => length_cnt(0),
	datad => \state.LOAD~q\,
	combout => \Selector10~0_combout\);

-- Location: LCCOMB_X3_Y13_N6
\target_ticks[0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \target_ticks[0]~feeder_combout\ = VCC

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \target_ticks[0]~feeder_combout\);

-- Location: FF_X3_Y13_N7
\target_ticks[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \target_ticks[0]~feeder_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \Selector10~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => target_ticks(0));

-- Location: LCCOMB_X5_Y14_N8
\RELOJ|Add0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~0_combout\ = \RELOJ|count\(0) $ (VCC)
-- \RELOJ|Add0~1\ = CARRY(\RELOJ|count\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(0),
	datad => VCC,
	combout => \RELOJ|Add0~0_combout\,
	cout => \RELOJ|Add0~1\);

-- Location: FF_X5_Y14_N9
\RELOJ|count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(0));

-- Location: LCCOMB_X5_Y14_N10
\RELOJ|Add0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~2_combout\ = (\RELOJ|count\(1) & (!\RELOJ|Add0~1\)) # (!\RELOJ|count\(1) & ((\RELOJ|Add0~1\) # (GND)))
-- \RELOJ|Add0~3\ = CARRY((!\RELOJ|Add0~1\) # (!\RELOJ|count\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(1),
	datad => VCC,
	cin => \RELOJ|Add0~1\,
	combout => \RELOJ|Add0~2_combout\,
	cout => \RELOJ|Add0~3\);

-- Location: FF_X5_Y14_N11
\RELOJ|count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(1));

-- Location: LCCOMB_X5_Y14_N12
\RELOJ|Add0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~4_combout\ = (\RELOJ|count\(2) & (\RELOJ|Add0~3\ $ (GND))) # (!\RELOJ|count\(2) & (!\RELOJ|Add0~3\ & VCC))
-- \RELOJ|Add0~5\ = CARRY((\RELOJ|count\(2) & !\RELOJ|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(2),
	datad => VCC,
	cin => \RELOJ|Add0~3\,
	combout => \RELOJ|Add0~4_combout\,
	cout => \RELOJ|Add0~5\);

-- Location: FF_X5_Y14_N13
\RELOJ|count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~4_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(2));

-- Location: LCCOMB_X5_Y14_N14
\RELOJ|Add0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~6_combout\ = (\RELOJ|count\(3) & (!\RELOJ|Add0~5\)) # (!\RELOJ|count\(3) & ((\RELOJ|Add0~5\) # (GND)))
-- \RELOJ|Add0~7\ = CARRY((!\RELOJ|Add0~5\) # (!\RELOJ|count\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(3),
	datad => VCC,
	cin => \RELOJ|Add0~5\,
	combout => \RELOJ|Add0~6_combout\,
	cout => \RELOJ|Add0~7\);

-- Location: FF_X5_Y14_N15
\RELOJ|count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(3));

-- Location: LCCOMB_X5_Y14_N16
\RELOJ|Add0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~8_combout\ = (\RELOJ|count\(4) & (\RELOJ|Add0~7\ $ (GND))) # (!\RELOJ|count\(4) & (!\RELOJ|Add0~7\ & VCC))
-- \RELOJ|Add0~9\ = CARRY((\RELOJ|count\(4) & !\RELOJ|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(4),
	datad => VCC,
	cin => \RELOJ|Add0~7\,
	combout => \RELOJ|Add0~8_combout\,
	cout => \RELOJ|Add0~9\);

-- Location: FF_X5_Y14_N17
\RELOJ|count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(4));

-- Location: LCCOMB_X5_Y14_N18
\RELOJ|Add0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~10_combout\ = (\RELOJ|count\(5) & (!\RELOJ|Add0~9\)) # (!\RELOJ|count\(5) & ((\RELOJ|Add0~9\) # (GND)))
-- \RELOJ|Add0~11\ = CARRY((!\RELOJ|Add0~9\) # (!\RELOJ|count\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(5),
	datad => VCC,
	cin => \RELOJ|Add0~9\,
	combout => \RELOJ|Add0~10_combout\,
	cout => \RELOJ|Add0~11\);

-- Location: FF_X5_Y14_N19
\RELOJ|count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(5));

-- Location: LCCOMB_X5_Y14_N20
\RELOJ|Add0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~12_combout\ = (\RELOJ|count\(6) & (\RELOJ|Add0~11\ $ (GND))) # (!\RELOJ|count\(6) & (!\RELOJ|Add0~11\ & VCC))
-- \RELOJ|Add0~13\ = CARRY((\RELOJ|count\(6) & !\RELOJ|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(6),
	datad => VCC,
	cin => \RELOJ|Add0~11\,
	combout => \RELOJ|Add0~12_combout\,
	cout => \RELOJ|Add0~13\);

-- Location: LCCOMB_X5_Y14_N2
\RELOJ|count~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~11_combout\ = (\RELOJ|Add0~12_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Add0~12_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~11_combout\);

-- Location: FF_X5_Y14_N3
\RELOJ|count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~11_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(6));

-- Location: LCCOMB_X5_Y14_N22
\RELOJ|Add0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~14_combout\ = (\RELOJ|count\(7) & (!\RELOJ|Add0~13\)) # (!\RELOJ|count\(7) & ((\RELOJ|Add0~13\) # (GND)))
-- \RELOJ|Add0~15\ = CARRY((!\RELOJ|Add0~13\) # (!\RELOJ|count\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(7),
	datad => VCC,
	cin => \RELOJ|Add0~13\,
	combout => \RELOJ|Add0~14_combout\,
	cout => \RELOJ|Add0~15\);

-- Location: FF_X5_Y14_N23
\RELOJ|count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~14_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(7));

-- Location: LCCOMB_X5_Y14_N24
\RELOJ|Add0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~16_combout\ = (\RELOJ|count\(8) & (\RELOJ|Add0~15\ $ (GND))) # (!\RELOJ|count\(8) & (!\RELOJ|Add0~15\ & VCC))
-- \RELOJ|Add0~17\ = CARRY((\RELOJ|count\(8) & !\RELOJ|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(8),
	datad => VCC,
	cin => \RELOJ|Add0~15\,
	combout => \RELOJ|Add0~16_combout\,
	cout => \RELOJ|Add0~17\);

-- Location: FF_X5_Y14_N25
\RELOJ|count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~16_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(8));

-- Location: LCCOMB_X5_Y14_N4
\RELOJ|Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~5_combout\ = (\RELOJ|count\(5) & (!\RELOJ|count\(6) & (!\RELOJ|count\(7) & !\RELOJ|count\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(5),
	datab => \RELOJ|count\(6),
	datac => \RELOJ|count\(7),
	datad => \RELOJ|count\(8),
	combout => \RELOJ|Equal0~5_combout\);

-- Location: LCCOMB_X5_Y14_N6
\RELOJ|Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~6_combout\ = (\RELOJ|count\(3) & (\RELOJ|count\(1) & (\RELOJ|count\(2) & \RELOJ|count\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(3),
	datab => \RELOJ|count\(1),
	datac => \RELOJ|count\(2),
	datad => \RELOJ|count\(4),
	combout => \RELOJ|Equal0~6_combout\);

-- Location: LCCOMB_X5_Y14_N26
\RELOJ|Add0~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~18_combout\ = (\RELOJ|count\(9) & (!\RELOJ|Add0~17\)) # (!\RELOJ|count\(9) & ((\RELOJ|Add0~17\) # (GND)))
-- \RELOJ|Add0~19\ = CARRY((!\RELOJ|Add0~17\) # (!\RELOJ|count\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(9),
	datad => VCC,
	cin => \RELOJ|Add0~17\,
	combout => \RELOJ|Add0~18_combout\,
	cout => \RELOJ|Add0~19\);

-- Location: FF_X5_Y14_N27
\RELOJ|count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~18_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(9));

-- Location: LCCOMB_X5_Y14_N28
\RELOJ|Add0~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~20_combout\ = (\RELOJ|count\(10) & (\RELOJ|Add0~19\ $ (GND))) # (!\RELOJ|count\(10) & (!\RELOJ|Add0~19\ & VCC))
-- \RELOJ|Add0~21\ = CARRY((\RELOJ|count\(10) & !\RELOJ|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(10),
	datad => VCC,
	cin => \RELOJ|Add0~19\,
	combout => \RELOJ|Add0~20_combout\,
	cout => \RELOJ|Add0~21\);

-- Location: FF_X5_Y14_N29
\RELOJ|count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~20_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(10));

-- Location: LCCOMB_X5_Y14_N30
\RELOJ|Add0~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~22_combout\ = (\RELOJ|count\(11) & (!\RELOJ|Add0~21\)) # (!\RELOJ|count\(11) & ((\RELOJ|Add0~21\) # (GND)))
-- \RELOJ|Add0~23\ = CARRY((!\RELOJ|Add0~21\) # (!\RELOJ|count\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(11),
	datad => VCC,
	cin => \RELOJ|Add0~21\,
	combout => \RELOJ|Add0~22_combout\,
	cout => \RELOJ|Add0~23\);

-- Location: LCCOMB_X5_Y14_N0
\RELOJ|count~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~10_combout\ = (\RELOJ|Add0~22_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RELOJ|Add0~22_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~10_combout\);

-- Location: FF_X5_Y14_N1
\RELOJ|count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~10_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(11));

-- Location: LCCOMB_X5_Y13_N0
\RELOJ|Add0~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~24_combout\ = (\RELOJ|count\(12) & (\RELOJ|Add0~23\ $ (GND))) # (!\RELOJ|count\(12) & (!\RELOJ|Add0~23\ & VCC))
-- \RELOJ|Add0~25\ = CARRY((\RELOJ|count\(12) & !\RELOJ|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(12),
	datad => VCC,
	cin => \RELOJ|Add0~23\,
	combout => \RELOJ|Add0~24_combout\,
	cout => \RELOJ|Add0~25\);

-- Location: LCCOMB_X4_Y13_N28
\RELOJ|count~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~9_combout\ = (\RELOJ|Add0~24_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RELOJ|Add0~24_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~9_combout\);

-- Location: FF_X4_Y13_N29
\RELOJ|count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~9_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(12));

-- Location: LCCOMB_X5_Y13_N2
\RELOJ|Add0~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~26_combout\ = (\RELOJ|count\(13) & (!\RELOJ|Add0~25\)) # (!\RELOJ|count\(13) & ((\RELOJ|Add0~25\) # (GND)))
-- \RELOJ|Add0~27\ = CARRY((!\RELOJ|Add0~25\) # (!\RELOJ|count\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(13),
	datad => VCC,
	cin => \RELOJ|Add0~25\,
	combout => \RELOJ|Add0~26_combout\,
	cout => \RELOJ|Add0~27\);

-- Location: LCCOMB_X4_Y13_N20
\RELOJ|count~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~8_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~26_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~26_combout\,
	combout => \RELOJ|count~8_combout\);

-- Location: FF_X4_Y13_N21
\RELOJ|count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~8_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(13));

-- Location: LCCOMB_X5_Y13_N4
\RELOJ|Add0~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~28_combout\ = (\RELOJ|count\(14) & (\RELOJ|Add0~27\ $ (GND))) # (!\RELOJ|count\(14) & (!\RELOJ|Add0~27\ & VCC))
-- \RELOJ|Add0~29\ = CARRY((\RELOJ|count\(14) & !\RELOJ|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(14),
	datad => VCC,
	cin => \RELOJ|Add0~27\,
	combout => \RELOJ|Add0~28_combout\,
	cout => \RELOJ|Add0~29\);

-- Location: LCCOMB_X4_Y13_N10
\RELOJ|count~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~7_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~28_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~28_combout\,
	combout => \RELOJ|count~7_combout\);

-- Location: FF_X4_Y13_N11
\RELOJ|count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~7_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(14));

-- Location: LCCOMB_X5_Y13_N6
\RELOJ|Add0~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~30_combout\ = (\RELOJ|count\(15) & (!\RELOJ|Add0~29\)) # (!\RELOJ|count\(15) & ((\RELOJ|Add0~29\) # (GND)))
-- \RELOJ|Add0~31\ = CARRY((!\RELOJ|Add0~29\) # (!\RELOJ|count\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(15),
	datad => VCC,
	cin => \RELOJ|Add0~29\,
	combout => \RELOJ|Add0~30_combout\,
	cout => \RELOJ|Add0~31\);

-- Location: FF_X5_Y13_N7
\RELOJ|count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~30_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(15));

-- Location: LCCOMB_X5_Y13_N8
\RELOJ|Add0~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~32_combout\ = (\RELOJ|count\(16) & (\RELOJ|Add0~31\ $ (GND))) # (!\RELOJ|count\(16) & (!\RELOJ|Add0~31\ & VCC))
-- \RELOJ|Add0~33\ = CARRY((\RELOJ|count\(16) & !\RELOJ|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(16),
	datad => VCC,
	cin => \RELOJ|Add0~31\,
	combout => \RELOJ|Add0~32_combout\,
	cout => \RELOJ|Add0~33\);

-- Location: LCCOMB_X5_Y13_N30
\RELOJ|count~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~6_combout\ = (\RELOJ|Add0~32_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RELOJ|Add0~32_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~6_combout\);

-- Location: FF_X5_Y13_N31
\RELOJ|count[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~6_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(16));

-- Location: LCCOMB_X4_Y13_N30
\RELOJ|Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~2_combout\ = (\RELOJ|count\(14) & (!\RELOJ|count\(15) & (\RELOJ|count\(16) & \RELOJ|count\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(14),
	datab => \RELOJ|count\(15),
	datac => \RELOJ|count\(16),
	datad => \RELOJ|count\(13),
	combout => \RELOJ|Equal0~2_combout\);

-- Location: LCCOMB_X5_Y13_N10
\RELOJ|Add0~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~34_combout\ = (\RELOJ|count\(17) & (!\RELOJ|Add0~33\)) # (!\RELOJ|count\(17) & ((\RELOJ|Add0~33\) # (GND)))
-- \RELOJ|Add0~35\ = CARRY((!\RELOJ|Add0~33\) # (!\RELOJ|count\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(17),
	datad => VCC,
	cin => \RELOJ|Add0~33\,
	combout => \RELOJ|Add0~34_combout\,
	cout => \RELOJ|Add0~35\);

-- Location: FF_X5_Y13_N11
\RELOJ|count[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~34_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(17));

-- Location: LCCOMB_X5_Y13_N12
\RELOJ|Add0~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~36_combout\ = (\RELOJ|count\(18) & (\RELOJ|Add0~35\ $ (GND))) # (!\RELOJ|count\(18) & (!\RELOJ|Add0~35\ & VCC))
-- \RELOJ|Add0~37\ = CARRY((\RELOJ|count\(18) & !\RELOJ|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|count\(18),
	datad => VCC,
	cin => \RELOJ|Add0~35\,
	combout => \RELOJ|Add0~36_combout\,
	cout => \RELOJ|Add0~37\);

-- Location: LCCOMB_X5_Y13_N28
\RELOJ|count~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~5_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~36_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~36_combout\,
	combout => \RELOJ|count~5_combout\);

-- Location: FF_X5_Y13_N29
\RELOJ|count[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~5_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(18));

-- Location: LCCOMB_X5_Y13_N14
\RELOJ|Add0~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~38_combout\ = (\RELOJ|count\(19) & (!\RELOJ|Add0~37\)) # (!\RELOJ|count\(19) & ((\RELOJ|Add0~37\) # (GND)))
-- \RELOJ|Add0~39\ = CARRY((!\RELOJ|Add0~37\) # (!\RELOJ|count\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(19),
	datad => VCC,
	cin => \RELOJ|Add0~37\,
	combout => \RELOJ|Add0~38_combout\,
	cout => \RELOJ|Add0~39\);

-- Location: LCCOMB_X4_Y13_N26
\RELOJ|count~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~4_combout\ = (\RELOJ|Add0~38_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RELOJ|Add0~38_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~4_combout\);

-- Location: FF_X4_Y13_N27
\RELOJ|count[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~4_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(19));

-- Location: LCCOMB_X5_Y13_N16
\RELOJ|Add0~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~40_combout\ = (\RELOJ|count\(20) & (\RELOJ|Add0~39\ $ (GND))) # (!\RELOJ|count\(20) & (!\RELOJ|Add0~39\ & VCC))
-- \RELOJ|Add0~41\ = CARRY((\RELOJ|count\(20) & !\RELOJ|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(20),
	datad => VCC,
	cin => \RELOJ|Add0~39\,
	combout => \RELOJ|Add0~40_combout\,
	cout => \RELOJ|Add0~41\);

-- Location: LCCOMB_X4_Y13_N16
\RELOJ|count~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~3_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~40_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~40_combout\,
	combout => \RELOJ|count~3_combout\);

-- Location: FF_X4_Y13_N17
\RELOJ|count[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~3_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(20));

-- Location: LCCOMB_X4_Y13_N4
\RELOJ|Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~1_combout\ = (\RELOJ|count\(19) & (\RELOJ|count\(20) & (!\RELOJ|count\(17) & \RELOJ|count\(18))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(19),
	datab => \RELOJ|count\(20),
	datac => \RELOJ|count\(17),
	datad => \RELOJ|count\(18),
	combout => \RELOJ|Equal0~1_combout\);

-- Location: LCCOMB_X4_Y13_N14
\RELOJ|Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~3_combout\ = (\RELOJ|count\(12) & (!\RELOJ|count\(10) & (!\RELOJ|count\(9) & \RELOJ|count\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(12),
	datab => \RELOJ|count\(10),
	datac => \RELOJ|count\(9),
	datad => \RELOJ|count\(11),
	combout => \RELOJ|Equal0~3_combout\);

-- Location: LCCOMB_X5_Y13_N18
\RELOJ|Add0~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~42_combout\ = (\RELOJ|count\(21) & (!\RELOJ|Add0~41\)) # (!\RELOJ|count\(21) & ((\RELOJ|Add0~41\) # (GND)))
-- \RELOJ|Add0~43\ = CARRY((!\RELOJ|Add0~41\) # (!\RELOJ|count\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(21),
	datad => VCC,
	cin => \RELOJ|Add0~41\,
	combout => \RELOJ|Add0~42_combout\,
	cout => \RELOJ|Add0~43\);

-- Location: LCCOMB_X5_Y13_N26
\RELOJ|count~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~2_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~42_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~42_combout\,
	combout => \RELOJ|count~2_combout\);

-- Location: FF_X5_Y13_N27
\RELOJ|count[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(21));

-- Location: LCCOMB_X5_Y13_N20
\RELOJ|Add0~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~44_combout\ = (\RELOJ|count\(22) & (\RELOJ|Add0~43\ $ (GND))) # (!\RELOJ|count\(22) & (!\RELOJ|Add0~43\ & VCC))
-- \RELOJ|Add0~45\ = CARRY((\RELOJ|count\(22) & !\RELOJ|Add0~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(22),
	datad => VCC,
	cin => \RELOJ|Add0~43\,
	combout => \RELOJ|Add0~44_combout\,
	cout => \RELOJ|Add0~45\);

-- Location: LCCOMB_X4_Y13_N8
\RELOJ|count~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~1_combout\ = (\RELOJ|Add0~44_combout\ & !\RELOJ|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RELOJ|Add0~44_combout\,
	datad => \RELOJ|Equal0~7_combout\,
	combout => \RELOJ|count~1_combout\);

-- Location: FF_X4_Y13_N9
\RELOJ|count[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(22));

-- Location: LCCOMB_X5_Y13_N22
\RELOJ|Add0~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~46_combout\ = (\RELOJ|count\(23) & (!\RELOJ|Add0~45\)) # (!\RELOJ|count\(23) & ((\RELOJ|Add0~45\) # (GND)))
-- \RELOJ|Add0~47\ = CARRY((!\RELOJ|Add0~45\) # (!\RELOJ|count\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(23),
	datad => VCC,
	cin => \RELOJ|Add0~45\,
	combout => \RELOJ|Add0~46_combout\,
	cout => \RELOJ|Add0~47\);

-- Location: FF_X5_Y13_N23
\RELOJ|count[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Add0~46_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(23));

-- Location: LCCOMB_X5_Y13_N24
\RELOJ|Add0~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Add0~48_combout\ = \RELOJ|Add0~47\ $ (!\RELOJ|count\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \RELOJ|count\(24),
	cin => \RELOJ|Add0~47\,
	combout => \RELOJ|Add0~48_combout\);

-- Location: LCCOMB_X4_Y13_N18
\RELOJ|count~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|count~0_combout\ = (!\RELOJ|Equal0~7_combout\ & \RELOJ|Add0~48_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RELOJ|Equal0~7_combout\,
	datad => \RELOJ|Add0~48_combout\,
	combout => \RELOJ|count~0_combout\);

-- Location: FF_X4_Y13_N19
\RELOJ|count[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|count~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|count\(24));

-- Location: LCCOMB_X4_Y13_N6
\RELOJ|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~0_combout\ = (!\RELOJ|count\(23) & (\RELOJ|count\(24) & (\RELOJ|count\(22) & \RELOJ|count\(21))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|count\(23),
	datab => \RELOJ|count\(24),
	datac => \RELOJ|count\(22),
	datad => \RELOJ|count\(21),
	combout => \RELOJ|Equal0~0_combout\);

-- Location: LCCOMB_X4_Y13_N12
\RELOJ|Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~4_combout\ = (\RELOJ|Equal0~2_combout\ & (\RELOJ|Equal0~1_combout\ & (\RELOJ|Equal0~3_combout\ & \RELOJ|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|Equal0~2_combout\,
	datab => \RELOJ|Equal0~1_combout\,
	datac => \RELOJ|Equal0~3_combout\,
	datad => \RELOJ|Equal0~0_combout\,
	combout => \RELOJ|Equal0~4_combout\);

-- Location: LCCOMB_X4_Y13_N24
\RELOJ|Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \RELOJ|Equal0~7_combout\ = (\RELOJ|Equal0~5_combout\ & (\RELOJ|Equal0~6_combout\ & (\RELOJ|count\(0) & \RELOJ|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RELOJ|Equal0~5_combout\,
	datab => \RELOJ|Equal0~6_combout\,
	datac => \RELOJ|count\(0),
	datad => \RELOJ|Equal0~4_combout\,
	combout => \RELOJ|Equal0~7_combout\);

-- Location: FF_X4_Y13_N25
\RELOJ|pulso\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \RELOJ|Equal0~7_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \RELOJ|pulso~q\);

-- Location: LCCOMB_X2_Y13_N24
\Selector10~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector10~1_combout\ = (\Selector10~0_combout\) # ((\state.PULSE~q\ & ((!\RELOJ|pulso~q\) # (!\state~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~12_combout\,
	datab => \RELOJ|pulso~q\,
	datac => \state.PULSE~q\,
	datad => \Selector10~0_combout\,
	combout => \Selector10~1_combout\);

-- Location: FF_X2_Y13_N25
\state.PULSE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector10~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.PULSE~q\);

-- Location: LCCOMB_X3_Y13_N2
\Selector13~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector13~0_combout\ = (!\state~12_combout\ & (!pulse_ticks(0) & \state.PULSE~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state~12_combout\,
	datac => pulse_ticks(0),
	datad => \state.PULSE~q\,
	combout => \Selector13~0_combout\);

-- Location: LCCOMB_X3_Y13_N0
\pulse_ticks[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \pulse_ticks[0]~0_combout\ = (\Selector10~0_combout\) # ((\state.PULSE~q\ & \RELOJ|pulso~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state.PULSE~q\,
	datac => \Selector10~0_combout\,
	datad => \RELOJ|pulso~q\,
	combout => \pulse_ticks[0]~0_combout\);

-- Location: FF_X3_Y13_N3
\pulse_ticks[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector13~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \pulse_ticks[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => pulse_ticks(0));

-- Location: LCCOMB_X1_Y13_N16
\Selector1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (\SW[0]~input_o\ & (!\SW[2]~input_o\)) # (!\SW[0]~input_o\ & ((\SW[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[0]~input_o\,
	datab => \SW[2]~input_o\,
	datad => \SW[1]~input_o\,
	combout => \Selector1~0_combout\);

-- Location: LCCOMB_X1_Y13_N30
\Selector2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (!\SW[0]~input_o\ & (\SW[2]~input_o\ $ (!\SW[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[0]~input_o\,
	datab => \SW[2]~input_o\,
	datad => \SW[1]~input_o\,
	combout => \Selector2~0_combout\);

-- Location: LCCOMB_X2_Y13_N12
\Selector3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~0_combout\ = (\SW[2]~input_o\ & (!\SW[1]~input_o\ & \SW[0]~input_o\)) # (!\SW[2]~input_o\ & (\SW[1]~input_o\ & !\SW[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datac => \SW[1]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector3~0_combout\);

-- Location: FF_X2_Y13_N13
\shift_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector3~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \state.LOAD~q\,
	ena => \ALT_INV_shift_reg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(1));

-- Location: FF_X1_Y13_N31
\shift_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector2~0_combout\,
	asdata => shift_reg(1),
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \state.LOAD~q\,
	ena => \ALT_INV_shift_reg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(2));

-- Location: FF_X1_Y13_N17
\shift_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector1~0_combout\,
	asdata => shift_reg(2),
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \state.LOAD~q\,
	ena => \ALT_INV_shift_reg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shift_reg(3));

-- Location: FF_X3_Y13_N5
\target_ticks[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	asdata => shift_reg(3),
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Selector10~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => target_ticks(1));

-- Location: LCCOMB_X3_Y13_N12
\Selector12~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector12~0_combout\ = (\state.PULSE~q\ & (!\state~12_combout\ & (pulse_ticks(1) $ (pulse_ticks(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.PULSE~q\,
	datab => \state~12_combout\,
	datac => pulse_ticks(1),
	datad => pulse_ticks(0),
	combout => \Selector12~0_combout\);

-- Location: FF_X3_Y13_N13
\pulse_ticks[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector12~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \pulse_ticks[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => pulse_ticks(1));

-- Location: LCCOMB_X3_Y13_N4
\state~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \state~12_combout\ = (target_ticks(0) & (!pulse_ticks(0) & (target_ticks(1) $ (!pulse_ticks(1))))) # (!target_ticks(0) & (pulse_ticks(0) & (target_ticks(1) & !pulse_ticks(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000001000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => target_ticks(0),
	datab => pulse_ticks(0),
	datac => target_ticks(1),
	datad => pulse_ticks(1),
	combout => \state~12_combout\);

-- Location: LCCOMB_X2_Y13_N0
\Selector11~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector11~0_combout\ = (\RELOJ|pulso~q\ & (\state~12_combout\ & (\state.PULSE~q\))) # (!\RELOJ|pulso~q\ & (((\state.SPACE~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~12_combout\,
	datab => \state.PULSE~q\,
	datac => \state.SPACE~q\,
	datad => \RELOJ|pulso~q\,
	combout => \Selector11~0_combout\);

-- Location: FF_X2_Y13_N1
\state.SPACE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector11~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.SPACE~q\);

-- Location: LCCOMB_X2_Y13_N6
\Selector8~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector8~1_combout\ = (\state.LOAD~q\) # ((\state.SPACE~q\ & \RELOJ|pulso~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state.SPACE~q\,
	datac => \state.LOAD~q\,
	datad => \RELOJ|pulso~q\,
	combout => \Selector8~1_combout\);

-- Location: LCCOMB_X1_Y13_N0
\Selector8~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector8~2_combout\ = (\KEY[1]~input_o\ & (\state.IDLE~q\ & ((!\Selector8~1_combout\) # (!\Selector8~0_combout\)))) # (!\KEY[1]~input_o\ & (((!\Selector8~1_combout\)) # (!\Selector8~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datab => \Selector8~0_combout\,
	datac => \state.IDLE~q\,
	datad => \Selector8~1_combout\,
	combout => \Selector8~2_combout\);

-- Location: FF_X1_Y13_N1
\state.IDLE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector8~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.IDLE~q\);

-- Location: LCCOMB_X1_Y13_N6
\shift_reg[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shift_reg[3]~0_combout\ = (!\Selector10~0_combout\ & ((\KEY[1]~input_o\) # (\state.IDLE~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datac => \Selector10~0_combout\,
	datad => \state.IDLE~q\,
	combout => \shift_reg[3]~0_combout\);

-- Location: LCCOMB_X1_Y13_N2
\length_cnt[1]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[1]~4_combout\ = (!\state.LOAD~q\ & ((\SW[1]~input_o\ & (\SW[2]~input_o\ $ (\SW[0]~input_o\))) # (!\SW[1]~input_o\ & (!\SW[2]~input_o\ & !\SW[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000101001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[1]~input_o\,
	datab => \SW[2]~input_o\,
	datac => \SW[0]~input_o\,
	datad => \state.LOAD~q\,
	combout => \length_cnt[1]~4_combout\);

-- Location: LCCOMB_X1_Y13_N28
\length_cnt[1]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[1]~3_combout\ = (\state.LOAD~q\ & (length_cnt(1) $ (!length_cnt(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => length_cnt(1),
	datac => length_cnt(0),
	datad => \state.LOAD~q\,
	combout => \length_cnt[1]~3_combout\);

-- Location: LCCOMB_X1_Y13_N10
\length_cnt[1]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \length_cnt[1]~5_combout\ = (\shift_reg[3]~0_combout\ & (((length_cnt(1))))) # (!\shift_reg[3]~0_combout\ & ((\length_cnt[1]~4_combout\) # ((\length_cnt[1]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \shift_reg[3]~0_combout\,
	datab => \length_cnt[1]~4_combout\,
	datac => length_cnt(1),
	datad => \length_cnt[1]~3_combout\,
	combout => \length_cnt[1]~5_combout\);

-- Location: FF_X1_Y13_N11
\length_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \length_cnt[1]~5_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => length_cnt(1));

-- Location: LCCOMB_X1_Y13_N24
\Selector8~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector8~0_combout\ = (!length_cnt(1) & (!length_cnt(0) & !length_cnt(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => length_cnt(1),
	datab => length_cnt(0),
	datac => length_cnt(2),
	combout => \Selector8~0_combout\);

-- Location: LCCOMB_X1_Y13_N26
\Selector9~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector9~0_combout\ = (!\KEY[1]~input_o\ & !\state.IDLE~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY[1]~input_o\,
	datad => \state.IDLE~q\,
	combout => \Selector9~0_combout\);

-- Location: LCCOMB_X2_Y13_N26
\Selector9~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector9~1_combout\ = (\Selector9~0_combout\) # ((!\Selector8~0_combout\ & (\state.SPACE~q\ & \RELOJ|pulso~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector8~0_combout\,
	datab => \state.SPACE~q\,
	datac => \Selector9~0_combout\,
	datad => \RELOJ|pulso~q\,
	combout => \Selector9~1_combout\);

-- Location: FF_X2_Y13_N27
\state.LOAD\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector9~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.LOAD~q\);

-- Location: LCCOMB_X2_Y13_N30
\Selector0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (\state.PULSE~q\) # ((\state.LOAD~q\ & \LEDR[0]~reg0_q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.LOAD~q\,
	datac => \LEDR[0]~reg0_q\,
	datad => \state.PULSE~q\,
	combout => \Selector0~0_combout\);

-- Location: FF_X2_Y13_N31
\LEDR[0]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector0~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \LEDR[0]~reg0_q\);

ww_LEDR(0) <= \LEDR[0]~output_o\;
END structure;


